package com.prenotaEventi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.prenotaEventi.prenotaEventi.model")
public class PrenotaEventiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrenotaEventiApplication.class, args);
    }
}