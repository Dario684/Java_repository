package com.prenotaEventi.service;

import com.prenotaEventi.model.Ruolo;
import com.prenotaEventi.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    // Salva un ruolo
    public Ruolo saveRole(Ruolo ruolo) {
        return roleRepository.save(ruolo);
    }

    // Recupera tutti i ruoli
    public List<Ruolo> getAllRoles() {
        return roleRepository.findAll();
    }

    // Cerca un ruolo per ID
    public Optional<Ruolo> getRoleById(Long id) {
        return roleRepository.findById(id);
    }

    // Cerca un ruolo per nome
    public Ruolo getRoleByNome(String nome) {
        return roleRepository.findByNome(nome);
    }

    // Elimina un ruolo per ID
    public void deleteRole(Long id) {
        roleRepository.deleteById(id);
    }
}
