package com.prenotaEventi.model;

import jakarta.persistence.*;

import java.util.Set;

@Entity
@Table(name = "ruolo")
public class Ruolo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;

    @ManyToMany(mappedBy = "ruoli")
    private Set<User> utenti;

    public Ruolo() {}

    public Ruolo(String nome) {
        this.nome = nome;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public Set<User> getUtenti() { return utenti; }
    public void setUtenti(Set<User> utenti) { this.utenti = utenti; }
}
