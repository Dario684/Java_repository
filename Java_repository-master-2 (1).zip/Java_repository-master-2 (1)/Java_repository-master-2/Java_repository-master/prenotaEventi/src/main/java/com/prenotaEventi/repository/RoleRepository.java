package com.prenotaEventi.repository;

import com.prenotaEventi.model.Ruolo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Ruolo, Long> {
    Ruolo findByNome(String nome);
}
