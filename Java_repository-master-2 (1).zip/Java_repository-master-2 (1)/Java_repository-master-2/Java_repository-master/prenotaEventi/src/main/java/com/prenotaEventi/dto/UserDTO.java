package com.prenotaEventi.dto;

import com.prenotaEventi.model.User;

import java.util.Set;
import java.util.stream.Collectors;


public class UserDTO {
    private Long id;
    private String username;
    private Set<String> roles;

    public UserDTO(Long id, String username, Set<String> roles) {
        this.id = id;
        this.username = username;
        this.roles = roles;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public Set<String> getRoles() { return roles; }
    public void setRoles(Set<String> roles) { this.roles = roles; }

    private UserDTO convertToDTO(User user) {
        Set<String> ruoli = user.getRuoli()
                .stream()
                .map(ruolo -> ruolo.getNome())  // assuming Ruolo ha getNome()
                .collect(Collectors.toSet());

        return new UserDTO(user.getId(), user.getUsername(), ruoli);
    }


}
