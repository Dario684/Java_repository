package com.prenotaEventi.controller;

import com.prenotaEventi.model.Ruolo;
import com.prenotaEventi.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/roles")
public class RoleController {

    @Autowired
    private RoleService roleService;

    // Crea un nuovo ruolo
    @PostMapping
    public Ruolo createRole(@RequestBody Ruolo ruolo) {
        return roleService.saveRole(ruolo);
    }

    // Ottieni tutti i ruoli
    @GetMapping
    public List<Ruolo> getAllRoles() {
        return roleService.getAllRoles();
    }

    // Cerca un ruolo per id
    @GetMapping("/{id}")
    public ResponseEntity<Ruolo> getRoleById(@PathVariable Long id) {
        Optional<Ruolo> ruolo = roleService.getRoleById(id);
        return ruolo.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Cerca un ruolo per nome
    @GetMapping("/name/{nome}")
    public ResponseEntity<Ruolo> getRoleByNome(@PathVariable String nome) {
        Ruolo ruolo = roleService.getRoleByNome(nome);
        if (ruolo != null) {
            return ResponseEntity.ok(ruolo);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Elimina un ruolo
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRole(@PathVariable Long id) {
        roleService.deleteRole(id);
        return ResponseEntity.noContent().build();
    }
}
