package com.prenotaEvenenti.repository;

import com.prenotaEventi.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepository extends JpaRepository<Evento, Long> {
}
