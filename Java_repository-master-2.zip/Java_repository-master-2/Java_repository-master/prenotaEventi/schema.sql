-- ----------------------------------
-- 📂 Creazione schema base
-- ----------------------------------

DROP DATABASE IF EXISTS eventi_db;
CREATE DATABASE eventi_db;
USE eventi_db;

-- ----------------------------------
-- 👤 Tabella Utenti
-- ----------------------------------

CREATE TABLE utenti (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    enabled BOOLEAN DEFAULT true
);

-- ----------------------------------
-- 🛡️ Tabella Ruoli
-- ----------------------------------

CREATE TABLE ruoli (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- Relazione molti-a-molti Utenti ↔ Ruoli
CREATE TABLE utenti_ruoli (
    utente_id BIGINT NOT NULL,
    ruolo_id BIGINT NOT NULL,
    PRIMARY KEY (utente_id, ruolo_id),
    FOREIGN KEY (utente_id) REFERENCES utenti(id),
    FOREIGN KEY (ruolo_id) REFERENCES ruoli(id)
);

-- ----------------------------------
-- 📅 Tabella Eventi
-- ----------------------------------

CREATE TABLE eventi (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titolo VARCHAR(100) NOT NULL,
    descrizione TEXT,
    data_evento DATE,
    luogo VARCHAR(100),
    organizzatore_id BIGINT,
    FOREIGN KEY (organizzatore_id) REFERENCES utenti(id)
);

-- ----------------------------------
-- 📝 Tabella Prenotazioni
-- ----------------------------------

CREATE TABLE prenotazioni (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    utente_id BIGINT,
    evento_id BIGINT,
    data_prenotazione TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utente_id) REFERENCES utenti(id),
    FOREIGN KEY (evento_id) REFERENCES eventi(id)
);

-- ----------------------------------
-- 🔐 Dati di esempio
-- ----------------------------------

-- Ruoli
INSERT INTO ruoli (nome) VALUES ('ROLE_USER'), ('ROLE_ADMIN');

-- Utenti
INSERT INTO utenti (username, password, email, enabled)
VALUES
  ('admin', '$2a$10$abcdefghijklmnopqrstuv', 'admin@email.com', true),
  ('utente1', '$2a$10$abcdefghijklmnopqrstuv', 'user@email.com', true);

-- Associazioni Ruoli
INSERT INTO utenti_ruoli (utente_id, ruolo_id) VALUES
  (1, 2), -- admin → ROLE_ADMIN
  (2, 1); -- utente1 → ROLE_USER

-- Eventi
INSERT INTO eventi (titolo, descrizione, data_evento, luogo, organizzatore_id)
VALUES
  ('Evento Java', 'Workshop su Spring Boot', '2025-09-01', 'Milano', 1),
  ('Hackathon', 'Gara di coding', '2025-10-10', 'Roma', 2);

-- Prenotazioni
INSERT INTO prenotazioni (utente_id, evento_id)
VALUES
  (2, 1),
  (2, 2);
